# TaskService Enhanced (Single-File Integration of CS-320, CS-370, CS-340 Enhancements)

This artifact demonstrates **Software Design & Engineering**, **Algorithms & Data Structures**, and **Databases** concepts within a small Java service.

## Highlights
- **SDE (CS-320):** Custom `ValidationException`, strong validation helpers, refactoring to reduce duplication, and JavaDoc.
- **Algorithms (CS-370):** O(1) lookups via `HashMap`, clean helper methods, optional sorted view.
- **Databases (CS-340):** Repository interface with an in-memory implementation to show DB-seam (easily swappable to real DB).

## Layout
```
src/main/java/com/example/tasks/Task.java
src/main/java/com/example/tasks/TaskService.java
src/test/java/com/example/tasks/TaskTest.java
src/test/java/com/example/tasks/TaskServiceTest.java
pom.xml
```

## Build & Test (Maven)
```bash
mvn -q -e -DskipTests=false test
```
(Requires Java 17+ and Maven.)

## Manual Compile (no Maven)
```bash
javac -d out $(find src/main/java -name "*.java")
```

