package com.example.tasks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void equalsAndHashCodeUseId() {
        Task a = new Task(1L, "A", "O", "D");
        Task b = new Task(1L, "B", "X", "Y");
        assertEquals(a, b);
        assertEquals(a.hashCode(), b.hashCode());
    }

    @Test
    void toStringContainsFields() {
        Task t = new Task(42L, "Name", "Owner", "Desc");
        String s = t.toString();
        assertTrue(s.contains("42"));
        assertTrue(s.contains("Name"));
        assertTrue(s.contains("Owner"));
        assertTrue(s.contains("Desc"));
    }
}
