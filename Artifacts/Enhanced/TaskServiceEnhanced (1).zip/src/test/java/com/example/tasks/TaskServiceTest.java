package com.example.tasks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void addTask_and_getTask_success() {
        Task t = new Task(1L, "Task 1", "Alice", "First task");
        service.addTask(t);
        Task fetched = service.getTask(1L);
        assertEquals("Task 1", fetched.getName());
        assertEquals("Alice", fetched.getOwner());
    }

    @Test
    void addTask_rejectsDuplicateId() {
        Task t1 = new Task(1L, "T1", "A", "D");
        Task t2 = new Task(1L, "T2", "B", "E");
        service.addTask(t1);
        TaskService.ValidationException ex =
            assertThrows(TaskService.ValidationException.class, () -> service.addTask(t2));
        assertTrue(ex.getMessage().toLowerCase().contains("duplicate"));
    }

    @Test
    void addTask_rejectsInvalidFields() {
        Task badId = new Task(0L, "x", "y", "z");
        assertThrows(TaskService.ValidationException.class, () -> service.addTask(badId));

        Task blankName = new Task(2L, "   ", "y", "z");
        assertThrows(TaskService.ValidationException.class, () -> service.addTask(blankName));
    }

    @Test
    void updateTask_updatesOwnerAndDescription() {
        service.addTask(new Task(10L, "Do Work", "Bob", "Old"));
        Task updated = service.updateTask(10L, "Carol", "New");
        assertEquals("Carol", updated.getOwner());
        assertEquals("New", updated.getDescription());
    }

    @Test
    void updateTask_rejectsBlankFields() {
        service.addTask(new Task(11L, "T", "O", "D"));
        assertThrows(TaskService.ValidationException.class, () -> service.updateTask(11L, "  ", null));
        assertThrows(TaskService.ValidationException.class, () -> service.updateTask(11L, null, ""));
    }

    @Test
    void deleteTask_successAndNotFound() {
        service.addTask(new Task(20L, "T", "O", "D"));
        assertTrue(service.deleteTask(20L));
        assertThrows(TaskService.ValidationException.class, () -> service.getTask(20L));
        assertThrows(TaskService.ValidationException.class, () -> service.deleteTask(20L));
    }

    @Test
    void listTasksSortedByName_isCaseInsensitive() {
        service.addTask(new Task(1L, "bravo", "o", "d"));
        service.addTask(new Task(2L, "Alpha", "o", "d"));
        assertEquals("Alpha", service.listTasksSortedByName().get(0).getName());
    }
}
