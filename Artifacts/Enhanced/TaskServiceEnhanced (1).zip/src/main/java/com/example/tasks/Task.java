package com.example.tasks;

import java.util.Objects;

/**
 * Represents a task entity.
 * <p>
 * This class keeps the model deliberately lean. Validation of inputs is performed
 * in {@link TaskService} to keep setters simple and side-effect free.
 */
public class Task {
    private long taskId;
    private String name;
    private String owner;
    private String description;

    public Task(long taskId, String name, String owner, String description) {
        this.taskId = taskId;
        this.name = name;
        this.owner = owner;
        this.description = description;
    }

    public long getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getOwner() { return owner; }
    public String getDescription() { return description; }

    public void setName(String name) { this.name = name; }
    public void setOwner(String owner) { this.owner = owner; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return taskId == task.taskId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskId=" + taskId +
                ", name='" + name + ''' +
                ", owner='" + owner + ''' +
                ", description='" + description + ''' +
                '}';
    }
}
