package com.example.tasks;

import java.util.*;

/**
 * TaskService demonstrates integrated enhancements:
 * <ul>
 *   <li><b>Software Design & Engineering:</b> custom exception, validation helpers, refactoring.</li>
 *   <li><b>Algorithms & Data Structures:</b> O(1) operations using HashMap; sorted projection.</li>
 *   <li><b>Databases:</b> repository abstraction + in-memory implementation (DB seam).</li>
 * </ul>
 */
public class TaskService {

    /** Custom exception for clear, domain-specific validation errors. */
    public static class ValidationException extends RuntimeException {
        public ValidationException(String message) { super(message); }
    }

    /** Repository abstraction so we can swap to a real DB without changing service code. */
    public interface TaskRepository {
        boolean existsById(long id);
        Task save(Task t);
        Task findById(long id);
        boolean deleteById(long id);
        Collection<Task> findAll();
    }

    /** In-memory repository: O(1) lookups via HashMap. */
    public static class InMemoryTaskRepository implements TaskRepository {
        private final Map<Long, Task> store = new HashMap<>();
        @Override public boolean existsById(long id) { return store.containsKey(id); }
        @Override public Task save(Task t) { store.put(t.getTaskId(), t); return t; }
        @Override public Task findById(long id) { return store.get(id); }
        @Override public boolean deleteById(long id) { return store.remove(id) != null; }
        @Override public Collection<Task> findAll() { return store.values(); }
    }

    private final TaskRepository repo;

    /** Default constructor uses in-memory backend to keep this artifact single-file-friendly. */
    public TaskService() {
        this(new InMemoryTaskRepository());
    }

    /** Allows injecting a different repository (e.g., Mongo-backed) for testing or real DB usage. */
    public TaskService(TaskRepository repository) {
        this.repo = Objects.requireNonNull(repository, "repository");
    }

    /**
     * Adds a new task after validation.
     * @param task the new task
     * @return the stored task
     * @throws ValidationException if task is null, invalid, or duplicate id is used
     */
    public Task addTask(Task task) {
        validateTask(task);
        if (repo.existsById(task.getTaskId())) {
            throw new ValidationException("Duplicate taskId: " + task.getTaskId());
        }
        return repo.save(task);
    }

    /**
     * Returns an existing task by id.
     * @param id task identifier (positive)
     * @return the task
     * @throws ValidationException if id is invalid or task not found
     */
    public Task getTask(long id) {
        validateId(id);
        Task t = repo.findById(id);
        if (t == null) throw new ValidationException("Task not found: " + id);
        return t;
    }

    /**
     * Updates owner and/or description safely.
     * Fields left as null are not modified.
     * @param id id of the task
     * @param newOwner new owner (non-blank if provided)
     * @param newDescription new description (non-blank if provided)
     * @return updated task
     */
    public Task updateTask(long id, String newOwner, String newDescription) {
        Task t = getTask(id); // reuses validation + not-found check
        if (newOwner != null)  t.setOwner(requireNonBlank(newOwner, "owner"));
        if (newDescription != null) t.setDescription(requireNonBlank(newDescription, "description"));
        return repo.save(t);
    }

    /**
     * Deletes a task by id.
     * @param id id to delete
     * @return true if deleted
     * @throws ValidationException if id invalid or not found
     */
    public boolean deleteTask(long id) {
        validateId(id);
        if (!repo.deleteById(id)) throw new ValidationException("Task not found: " + id);
        return true;
    }

    /** Returns a case-insensitive name-sorted list for UI/reporting use. */
    public List<Task> listTasksSortedByName() {
        return repo.findAll().stream()
                .sorted(Comparator.comparing(Task::getName, String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    // ----------------- Helpers (refactored to remove duplication) -----------------

    private void validateTask(Task task) {
        if (task == null) throw new ValidationException("Task cannot be null");
        validateId(task.getTaskId());
        requireNonBlank(task.getName(), "name");
        requireNonBlank(task.getOwner(), "owner");
        requireNonBlank(task.getDescription(), "description");
    }

    private void validateId(long id) {
        if (id <= 0) throw new ValidationException("id must be positive");
    }

    private String requireNonBlank(String s, String field) {
        if (s == null || s.trim().isEmpty()) {
            throw new ValidationException(field + " cannot be blank");
        }
        return s.trim();
    }
}
