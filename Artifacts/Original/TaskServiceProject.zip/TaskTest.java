import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("001", "Buy Milk", "Go to the store and buy milk");
        assertEquals("001", task.getTaskId());
        assertEquals("Buy Milk", task.getName());
        assertEquals("Go to the store and buy milk", task.getDescription());
    }

    @Test
    public void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    public void testNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("001", null, "Description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        String longDesc = "a".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("002", "TaskName", longDesc);
        });
    }

    @Test
    public void testUpdateName() {
        Task task = new Task("003", "Initial", "Desc");
        task.setName("UpdatedName");
        assertEquals("UpdatedName", task.getName());
    }

    @Test
    public void testUpdateDescription() {
        Task task = new Task("004", "Name", "InitialDesc");
        task.setDescription("Updated Description");
        assertEquals("Updated Description", task.getDescription());
    }
}