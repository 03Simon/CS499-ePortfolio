import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("001", "Clean", "Clean your room");
        service.addTask(task);
        assertEquals(task, service.getTask("001"));
    }

    @Test
    public void testAddDuplicateTaskFails() {
        Task task1 = new Task("001", "Task1", "Description1");
        Task task2 = new Task("001", "Task2", "Description2");
        service.addTask(task1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task2));
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("002", "Delete Me", "To be deleted");
        service.addTask(task);
        service.deleteTask("002");
        assertNull(service.getTask("002"));
    }

    @Test
    public void testDeleteNonExistentTaskFails() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("999"));
    }

    @Test
    public void testUpdateTaskName() {
        Task task = new Task("003", "OldName", "Description");
        service.addTask(task);
        service.updateTaskName("003", "NewName");
        assertEquals("NewName", service.getTask("003").getName());
    }

    @Test
    public void testUpdateTaskDescription() {
        Task task = new Task("004", "Name", "Old Description");
        service.addTask(task);
        service.updateTaskDescription("004", "New Description");
        assertEquals("New Description", service.getTask("004").getDescription());
    }

    @Test
    public void testUpdateNonExistentTaskFails() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskName("999", "Name"));
    }
}